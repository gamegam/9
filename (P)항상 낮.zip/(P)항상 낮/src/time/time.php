<?php

namespace time;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class time extends PluginBase implements Listener{
	public $data, $db;
	public $eid;
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		@mkdir($this->getDataFolder());
		$this->data = new Config($this->getDataFolder() . "Data.yml", Config::YAML);
		$this->db = $this->data->getAll();
		$this->getScheduler()->scheduleRepeatingTask (new class($this) extends \pocketmine\scheduler\Task {
			private $owner;
			
			public function __construct(time $owner){
				$this->owner = $owner;
			}
			public function onRun(int $currentTick){
				foreach($this->owner->getServer()->getOnlinePlayers() as $player){
					if(!isset($this->owner->db[$player->getName()]))
						continue;
					if($this->owner->db[$player->getName()]["type"] == "true"){
						$this->owner->날($player);
					}
				}
			}
		}, 0);
	}
	public function onSave(){
		$this->data->setAll($this->db);
		$this->data->save();
	}
	public function onJoin(\pocketmine\event\player\PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		if(!isset($this->db[$name])){
			$this->db[$name] = [ ];
			$this->db[$name]["type"] = true;
			$this->onSave();
		}
	}
	
	public function 날(Player $player){
				foreach(Server::getInstance()->getLevels() as $level){
			$level->setTime(0);
	}
}
}